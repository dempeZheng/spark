package base;

import redis.clients.jedis.ShardedJedis;

import java.io.Serializable;

/**
 * Created by dempe on 14-5-16.
 */
public class UserDao implements Serializable {

    private static ShardedJedis shardedJedis;
    public UserDao(){
        shardedJedis = RedisPool.getJedis();
    }

    public  boolean isNewUser(String diviceId){
        return shardedJedis.get(diviceId)==null;
    }

    public boolean isActiveUser(String key,String deviceId){
        if(shardedJedis.get(key)==null) {
            shardedJedis.set(key, deviceId);
            return true;
        }
        return false;
    }
}
