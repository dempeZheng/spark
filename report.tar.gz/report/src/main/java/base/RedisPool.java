package base;

import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisShardInfo;
import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import java.util.LinkedList;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Created by dempe on 14-5-16.
 */
public class RedisPool {
    private static ShardedJedisPool pool;

    static {
        ResourceBundle bundle = ResourceBundle.getBundle("redis");
        if(bundle == null){
            throw new IllegalArgumentException("redis.properties is not found!");
        }
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxIdle(Integer.valueOf(bundle.getString("redis.pool.maxIdle")));
        config.setMaxWaitMillis(Long.valueOf(bundle.getString("redis.pool.maxWait")));
        config.setTestOnBorrow(Boolean.valueOf(bundle.getString("redis.pool.testOnBorrow")));
        config.setTestOnReturn(Boolean.valueOf(bundle.getString("redis.pool.testOnReturn")));
        String redisIp = bundle.getString("reids.ip");
        String ips[] = redisIp.split(",");
        List<JedisShardInfo> list = new LinkedList<JedisShardInfo>();
        for(String ip :ips){
            JedisShardInfo jedisShardInfo = new JedisShardInfo(ip,Integer.valueOf(bundle.getString("redis.port")));
            list.add(jedisShardInfo);
        }
        pool = new ShardedJedisPool(config,list);
    }

    public  static ShardedJedis getJedis(){
        return pool.getResource();
    }

    public static void returnJedis(ShardedJedis jedis){
        pool.returnResource(jedis);
    }

    public static void  main(String args[]){
        ShardedJedis shardedJedis = RedisPool.getJedis();
        shardedJedis.set("name","dempe");
        String name = shardedJedis.get("name");
        System.out.println("name :" + name);
    }
}
