package base;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by dempe on 14-5-15.
 */
public class DateUtils {

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private final static int TIMENUM = 1000;

    public static Date formtStrDate(String strDate) throws ParseException {
         return sdf.parse(strDate);
    }

    public static long getDatePeriod(String startDate,String endDate) throws ParseException {
       return  (formtStrDate(endDate).getTime()-formtStrDate(startDate).getTime())/TIMENUM;
    }
}
