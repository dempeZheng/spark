package spark.streaming

import scala.reflect.ClassTag
import org.apache.spark.streaming.dstream.DStream
import common.{ClientMessage, MongoBase, Constants}
import org.apache.spark.streaming.{Seconds, Minutes}
import com.mongodb.casbah.commons.MongoDBObject
import org.apache.spark.streaming._
import org.apache.spark.streaming.StreamingContext._
/**
 * Created by dempe on 14-5-20.
 */
object RunNumTest {

  def getRunNumReport(lines : DStream[ ClientMessage] ) = {
    val ver_chanel_daily =  lines.flatMap(line =>{
      val appver = line.deviceData.get(Constants.APPVER).getOrElse()
      val channelName = line.deviceData.get(Constants.CHANNEL_NAME).getOrElse()
      val model = line.deviceData.get(Constants.MODEL).getOrElse()
      val screensize = line.deviceData.get(Constants.SCREENSIZE).getOrElse()
      val sysver = line.deviceData.get(Constants.SYSVER).getOrElse()
      val carrier = line.deviceData.get(Constants.CARRIER).getOrElse()
      val networktype = line.deviceData.get(Constants.NETWORKTYPE).getOrElse()
      val province =line.deviceData.get(Constants.PROVINCE).getOrElse()
      val datas = Map(Constants.MODEL ->model,Constants.SCREENSIZE -> screensize,
        Constants.CHANNEL_NAME -> channelName, Constants.SYSVER -> sysver, Constants.CARRIER -> carrier,
        Constants.NETWORKTYPE -> networktype, Constants.PROVINCE -> province)
      line.launchData.map(ld =>
        (line.appkey + ":" +appver +":" + channelName + ":" + ld.get(Constants.CREATE_DATE).get.substring(0,10), datas))
    }).cache()


    val runNum = ver_chanel_daily.map(value => (value._1, 1)).
      reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1).print()
    // val mongoClient =  MongoClient("localhost", 27001)

    val propList = List(Constants.MODEL, Constants.CHANNEL_NAME, Constants.SCREENSIZE,Constants.SYSVER, Constants.CARRIER,
      Constants.NETWORKTYPE, Constants.PROVINCE)
    propList.foreach(prop => {
      ver_chanel_daily.map(value =>(value._1 + ":" + value._2.get(prop).getOrElse(), 1)).
        reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1).foreachRDD((rdd, time)=>{
        println("-----------------save value to mongo-------------")
        rdd.foreach(value =>{
          MongoBase.getClient()("test")("report").update(MongoDBObject("_id" ->value._1),MongoDBObject("run_num" ->value._2))
        })
      }
        )
    })

  }

}
