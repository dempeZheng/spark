package spark.streaming

import common.{UserRedisDao, Constants, ClientMessage}
import org.apache.spark.streaming.{Seconds, Minutes}
import org.apache.spark.streaming._
import org.apache.spark.streaming.StreamingContext._
/**
 * Created by dempe on 14-5-20.
 */
object NewDeviceReport {
  def main(args: Array[String]) {
    val ssc = SparkUtils.getSSC("spark-streaming-report")
    ssc.checkpoint("checkpoint")
    val lines = SparkUtils.getLinesFromKafka(ssc).map(m => ClientMessage.fromString(m._2))

    val ver_chanel_daily =  lines.filter(msg => UserRedisDao.isNewUser(msg.deviceData.get(Constants.DEVICE_ID).getOrElse(""))).
      flatMap(line =>{
      val appver = line.deviceData.get(Constants.APPVER).getOrElse()
      val channelName = line.deviceData.get(Constants.CHANNEL_NAME).getOrElse()
      val model = line.deviceData.get(Constants.MODEL).getOrElse()
      val screensize = line.deviceData.get(Constants.SCREENSIZE).getOrElse()
      val sysver = line.deviceData.get(Constants.SYSVER).getOrElse()
      val carrier = line.deviceData.get(Constants.CARRIER).getOrElse()
      val networktype = line.deviceData.get(Constants.NETWORKTYPE).getOrElse()
      val province =line.deviceData.get(Constants.PROVINCE).getOrElse()
      val datas = Map(Constants.MODEL ->model,Constants.SCREENSIZE -> screensize,
        Constants.CHANNEL_NAME -> channelName, Constants.SYSVER -> sysver, Constants.CARRIER -> carrier,
        Constants.NETWORKTYPE -> networktype, Constants.PROVINCE -> province)
      line.launchData.map(ld =>
        (line.appkey + ":" +appver +":" + channelName + ":" + ld.get(Constants.CREATE_DATE).get.substring(0,10),datas))
    }).cache()

    val runNum = ver_chanel_daily.map(value => (value._1, 1)).
         reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1).print()

    val propList = List(Constants.MODEL, Constants.CHANNEL_NAME, Constants.SCREENSIZE,Constants.SYSVER, Constants.CARRIER,
      Constants.NETWORKTYPE, Constants.PROVINCE)
    propList.foreach(prop => {
      ver_chanel_daily.map(value =>(value._1 + ":" + value._2.get(prop).getOrElse(), 1)).
        reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1).print()
    })

    ssc.start()
    ssc.awaitTermination()
  }

}
