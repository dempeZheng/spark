package spark.streaming

import common.{Constants, UserRedisDao, DeviceData, ClientMessage}
import org.apache.spark.streaming._
import org.apache.spark.streaming.StreamingContext._
import base.{DateUtils, UserDao}
import org.apache.spark.rdd.RDD


/**
 * Created by dempe on 14-5-16.
 */
object SparkStreamingReport {
  def main(args: Array[String]) {
    val ssc = SparkUtils.getSSC("spark-streaming-report")
    ssc.checkpoint("checkpoint")
    val lines = SparkUtils.getLinesFromKafka(ssc).map(m => ClientMessage.fromString(m._2))

    val sum_hourly = lines.flatMap(line =>{
      line.launchData.map(ld => (line.appkey + ":" + ld.get(Constants.CREATE_DATE).get.substring(0,13),
        line.deviceData.get(Constants.DEVICE_ID).get))
    })
    

    // sum_hourly report
    val hourly_run_num = sum_hourly.map(value =>(value._1, 1)).
      reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1).persist()

    val hourly_new_device = sum_hourly.filter(value => UserRedisDao.isNewUser(value._2)).map(value =>(value._1,1)).
      reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1).persist()



    // sum_daily report
    val daily_run_num = hourly_run_num.map(value =>{
      (value._1.substring(0,value._1.length-3),value._2)
    }). reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1)

    val daily_new_device = hourly_new_device.map(value =>(value._1.substring(0,value._1.length-3),value._2)).
      reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1)


    val sum_daily = lines.flatMap(line =>{
      line.exitData.map(ed => {
        val deviceId = line.deviceData.get(Constants.DEVICE_ID).get
        val createDate = ed.get(Constants.CREATE_DATE).get
        val endDate = ed.get(Constants.END_DATE).get
        val duration = DateUtils.getDatePeriod(createDate, endDate)
        val dataMap = Map(Constants.DEVICE_ID ->deviceId, "duration" -> duration )
        (line.appkey + ":" + createDate.substring(0,10), dataMap)
      })
    }).persist()

    val active_device = sum_daily.filter(value =>UserRedisDao.isActiveUser(value._1,value._2.get(Constants.DEVICE_ID).
      get.asInstanceOf[String])).map(value => (value._1,1))
      . reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1)

    val duration = sum_daily.map(value => (value._1, value._2.get("duration").get.asInstanceOf[Long]))
      .reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1)



    duration.print()
    duration.foreachRDD((rdd, time)=>{
      println("-----------------save value to redis-------------")
      rdd.foreach(value => UserRedisDao.saveDataRedis(value._1,value._2.toString))
    }
    )

    //***************************************************************************
    val base_map = lines.flatMap(line =>{
      val deviceId = line.deviceData.get(Constants.DEVICE_ID).get
      val appver = line.deviceData.get(Constants.APPVER).get
      val channelName = line.deviceData.get(Constants.CHANNEL_NAME).get
      line.exitData.map(ed => {
        val createDate = ed.get(Constants.CREATE_DATE).get
        val endDate = ed.get(Constants.END_DATE).get
        val duration = DateUtils.getDatePeriod(createDate, endDate)
        val dataMap = Map(Constants.DEVICE_ID ->deviceId,"duration" -> duration )
        (line.appkey + ":" + appver + ":" + channelName + ":" + createDate.substring(0,10), dataMap)
      })
    }).persist()

    val ver_channel_active_device = base_map.filter(value =>UserRedisDao.isActiveUser(value._1,value._2.get(Constants.DEVICE_ID).
      get.asInstanceOf[String])).map(value => (value._1,1))
      . reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1)

    val ver_channel_duration = base_map.map(value => (value._1, value._2.get("duration").get.asInstanceOf[Long]))
      .reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1)

    ver_channel_active_device.print()

    ver_channel_duration.map(value =>{
      val keys = value._1.split(":")
      (keys(0) + ":" +

        keys(3),value._2)
    }). reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1).print()



    ssc.start()
    ssc.awaitTermination()
  }

}
