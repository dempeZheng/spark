package spark.streaming

import common.ClientMessage

/**
 * Created by dempe on 14-5-20.
 */
object ReportTest {


  def main(args: Array[String]) {
    val ssc = SparkUtils.getSSC("spark-streaming-report")
    ssc.checkpoint("checkpoint")
    val lines = SparkUtils.getLinesFromKafka(ssc).map(m => ClientMessage.fromString(m._2))

    RunNumTest.getRunNumReport(lines)

    ssc.start()
  }

}
