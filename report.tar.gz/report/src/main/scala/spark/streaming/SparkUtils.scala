package spark.streaming

import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.kafka.KafkaUtils
import common.Constants

/**
 * Created by dempe on 14-5-16.
 */
object SparkUtils {
  def getSSC(appName : String) : StreamingContext= {
    val conf = new SparkConf()
    conf.setMaster(Constants.local)
    conf.setSparkHome(System.getenv(Constants.SPARK_HOME))
    conf.setAppName(appName)
    new StreamingContext(conf, Seconds(5))
  }

  def getLinesFromKafka(ssc : StreamingContext) :  DStream[(String, String)] ={
    val topicpMap = Constants.topics.split(",").map((_,Constants.numThreads.toInt)).toMap
    KafkaUtils.createStream(ssc, Constants.zkQuorum, Constants.group, topicpMap)

  }


}
