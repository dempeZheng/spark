package spark.streaming

import java.util.Properties
import kafka.producer.{KeyedMessage, Producer, ProducerConfig}
import common.MsgResource

/**
 * Created by dempe on 14-5-14.
 */
object KafkaRandomMsgProduce {

  def main(args: Array[String]) {

    val messagesPerSec = "10"
    val topic ="demo"
    val brokers = {"localhost:9092"}
    val wordsPerMessage = "100";

    val props = new Properties()
    props.put("metadata.broker.list", brokers)
    props.put("serializer.class", "kafka.serializer.StringEncoder")

    val config = new ProducerConfig(props)
    val producer = new Producer[String, String](config)




    val mr = new MsgResource()
    // Send some messages
    while(true) {
      val messages = (1 to messagesPerSec.toInt).map { messageNum =>
        val str = mr.getMsg()
        new KeyedMessage[String, String](topic, str)
      }.toArray

      producer.send(messages: _*)
      Thread.sleep(1000)
    }
  }




}
