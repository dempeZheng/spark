package spark.streaming

import common.{Constants, ClientMessage}
import org.apache.spark.streaming._
import org.apache.spark.streaming.StreamingContext._
/**
 * Created by dempe on 14-5-20.
 */
object SumBrowsingPagePath {
  
  def main(args: Array[String]) {
    val ssc = SparkUtils.getSSC("spark-streaming-report")
    ssc.checkpoint("checkpoint")
    val lines = SparkUtils.getLinesFromKafka(ssc).map(m => ClientMessage.fromString(m._2))


    lines.flatMap(line =>{
      val pageData = line.pageData
      val appver = line.deviceData.get(Constants.APPVER).getOrElse()
      val channelName = line.deviceData.get(Constants.CHANNEL_NAME).getOrElse()
      val fromPageList = pageData.map(pd => pd.get(Constants.FROM_PAGE))
      pageData.map(pd =>{
        val startDate = pd.get("start_date").getOrElse().asInstanceOf[String].substring(0,10)
        val page = pd.get("page").getOrElse()
        (line.appkey + ":" + appver + ":"+channelName+":" + startDate, page)
      }).filter(value => !fromPageList.contains(value._2.asInstanceOf[String])).map(value =>(value._1,1))
       //
    }). reduceByKeyAndWindow(_ + _, _ - _, Minutes(10), Seconds(5), 1).print()

    ssc.start()



  }

}
