package common

import redis.clients.jedis.ShardedJedis
import base.RedisPool

/**
 * Created by dempe on 14-5-19.
 */
class UserRedisDao {


}
object  UserRedisDao{
  val shardedJedis: ShardedJedis = RedisPool.getJedis
  def isNewUser(deviceId : String) : Boolean ={
    shardedJedis.get(deviceId) match {
      case null => true
      case _ => false
    }
  }
  def isActiveUser(key : String, deviceId : String) : Boolean = {
    if(shardedJedis.get(key) == null){
      shardedJedis.set(key,deviceId)
      true
    }else{
      false
    }
  }

  def saveDataRedis(key : String, value : String ) = {
    shardedJedis.set(key,value)
  }





}
