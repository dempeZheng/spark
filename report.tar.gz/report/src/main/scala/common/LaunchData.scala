package common

/**
 * Created by dempe on 14-5-16.
 */
class LaunchData (val lastEndDate : String, val createDate : String, val sessionId : String) extends Serializable{
  override def toString() : String = {
    "%s\t%s\t%s\n".format(lastEndDate, createDate, sessionId)
  }

}
object  LaunchData extends Serializable{
  def fromMap(launchDataMap : Map[String,String]) : LaunchData = {
    val lastEndDate = launchDataMap.get("last_end_date").get
    val createDate = launchDataMap.get("create_date").get
    val sessionId = launchDataMap.get("session_id").get
    new LaunchData(lastEndDate, createDate, sessionId)

  }
}
