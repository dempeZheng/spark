package common

import scala.util.parsing.json.JSON

/**
 * Created by dempe on 14-5-16.
 */
class ClientMessage(val deviceData : Map[String,String], val launchData : List[Map[String,String]], val exitData : List[Map[String,String]] ,
               val pageData : List[Map[String,String]], val eventData : List[Map[String,String]], val eventKvData : List[Map[String,String]],
               val errorData : List[Map[String,String]], val appkey : String)  extends Serializable{

}
object ClientMessage extends Serializable{

  def fromString(line : String) : ClientMessage = {
    val json = JSON.parseFull(line).get.asInstanceOf[Map[String,Any]]
    val m = json.get("m").get.asInstanceOf[Map[String,Any]]
    val deviceData = m.get("device_data").get.asInstanceOf[Map[String, String]]
    val launchData = m.get("launch_data").get.asInstanceOf[List[Map[String,String]]]
    val exitData = m.get("exit_data").get.asInstanceOf[List[Map[String,String]]]
    val pageData = m.get("page_data").get.asInstanceOf[List[Map[String,String]]]
    val eventData = m.get("event_data").get.asInstanceOf[List[Map[String,String]]]
    val eventKvData = m.get("eventkv_data").get.asInstanceOf[List[Map[String,String]]]
    val errorData = m.get("error_data").get.asInstanceOf[List[Map[String,String]]]
    val appkey = json.get("appkey").get.asInstanceOf[String]
    new ClientMessage(deviceData, launchData, exitData, pageData, eventData, eventKvData, errorData,appkey)

  }

}

