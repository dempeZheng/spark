package common

import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.Time
import org.apache.spark.streaming.dstream.ForEachDStream
import scala.reflect.ClassTag

/**
 * Created by dempe on 14-5-19.
 */
object OutputOperation {

  def saveDataToRedis[T : ClassTag](rdd: RDD[T]){
    val value = rdd.take(11)
    println(value.take(10).foreach(println))



  }

}
