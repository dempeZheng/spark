package common

/**
 * Created by dempe on 14-5-16.
 */
object Constants {

  val zkQuorum ="localhost:2181"
  val topics ="demo"
  val SPARK_HOME ="SPARK_HOME"
  val local = "local"
  val group = "my-consumer-group"
  val numThreads = "2"

  val CREATE_DATE = "create_date"
  val LAST_END_DATE ="last_end_date"
  val END_DATE ="end_date"
  val DEVICE_ID ="device_id"
  val LAUNCH_DATA ="launch_data"
  val DEVICE_DATA ="device_data"
  val APPVER  = "appver"
  val CHANNEL_NAME = "channel_name"
  val MODEL = "model"
  val SCREENSIZE = "screensize"
  val SYSVER = "sysver"
  val CARRIER ="carrier"
  val NETWORKTYPE = "networktype"
  val PROVINCE = "province"

  val PAGE ="page"
  val FROM_PAGE ="from_page"

}
