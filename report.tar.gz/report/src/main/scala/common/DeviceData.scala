package common

/**
 * Created by dempe on 14-5-16.
 */
class DeviceData(val deviceId : String, val appver : String, val apppkg : String, val platform : String, val sdkver : String,
                  val channelName : String, val screensize : String, val carrier : String) extends Serializable{

  override def toString() : String = {
    "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n".format(deviceId, appver, apppkg, platform, sdkver, channelName, screensize, carrier)
  }
}

object DeviceData extends Serializable{
  def fromMap(deviceDataMap : Map[String,String]) : DeviceData ={
    val deviceId = deviceDataMap.get("device_id").get
    val appver = deviceDataMap.get("appver").get
    val apppkg = deviceDataMap.get("apppkg").get
    val platform = String.valueOf(deviceDataMap.get("platform_id")).asInstanceOf[String]
    val sdkver = deviceDataMap.get("sdkver").get
    val channelName = deviceDataMap.get("channel_name").get
    val screensize = deviceDataMap.get("screensize").get
    val carrier = deviceDataMap.get("carrier").get
    new DeviceData(deviceId, appver, apppkg, platform, sdkver, channelName, screensize, carrier)
  }
}
