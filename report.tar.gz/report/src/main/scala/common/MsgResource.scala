package common

import java.util.Random

/**
 * Created by dempe on 14-5-14.
 */
class MsgResource {


  def getMsg():String = {
    val msg1= """{"m":{
                	"device_data": {
                	"device_id": "50589a7dc52a2d0",
                		"appver": "1.0",
                	"apppkg": " com.example.sharesdk_test",
                		"platform_id": 1,
                	"sdkver": "1.0.0",
                		"channel_name": "Channel_A",
                		"mac": "d8:50:e6:80:45:98",
                		"model": "Nexus 7",
                		"sysver": "4.4.2",
                		"carrier": "400001",
                		"screensize": "1200x1824",
                		"factory": " asus",
                		"networktype": "Wi-Fi",
                		"is_jailbroken": 0,
                		"longitude": "121.49656",
                		"latitude": "31.21842",
                		"language": "zh",
                		"timezone": 8,
                  	"cpu": "ARMv7 Processor rev 0 (v7l)",
                		"manuid": "KOT49H",
                		"manutime": "1386201442000"
                	},
                	"launch_data": [{
                		"last_end_date": "2014-02-21 12:40:19",
                		"create_date": "2014-02-21 14:40:19",
                		"session_id": "5CEEA3BFF862D1EE437A5A29EABEC372"
                	},
                	{
                		"last_end_date": "2014-02-21 11:50:19",
                		"create_date": "2014-02-21 14:40:19",
                		"session_id": "5CEEA3BFF862D1EE437A5A29EABEC373"
                	}],
                	"exit_data": [{
                		"create_date": "2014-02-21 14:40:19",
                		"end_date": "2014-02-21 16:40:19",
                		"session_id": "5CEEA3BFF862D1EE437A5A29EABEC372"
                	},
                	{
                		"create_date": "2014-02-21 14:40:19",
                		"end_date": "2014-02-21 15:40:19",
                		"session_id": "5CEEA3BFF862D1EE437A5A29EABEC373"
                	}],
                	"page_data": [{
                		"session_id": "087f742d7d2a34de7eaaf813e5069aaa",
                		"start_date": "2014-02-13 11:41:35",
                		"end_date": "2014-02-13 11:41:38",
                		"page": ".TestActivity",
                		" from_page": ".MainActivity",
                		"duration": 2861
                	}],
                	"event_data": [{
                		"session_id": "087f742d7d2a34de7eaaf813e5069aaa",
                		"create_date": "2014-02-13 11:43:54",
                		"eventkey": "btn_click",
                		"notice_num": 1,
                		"page": ".TestActivity",
                		"label": "stop",
                		"duration": 2861
                	}],
                	"eventkv_data": [{
                		"session_id": "087f742d7d2a34de7eaaf813e5069aaa",
                		"create_date": "2014-02-13 11:43:54",
                		"eventkey": "btn_click",
                		"page": ".MainActivity",
                		"key1": "value1",
                		"key2": "value2",
                		"key3": "value3",
                		"key4": "value4",
                		"key5": "value5",
                		"key6": "value6",
                		"key7": "value7",
                		"key8": "value8",
                		"key9": "value9",
                		"key10": "value10",
                		"notice_num": 1,
                		"label": "stop",
                		"duration": 2861
                	}],
                	"error_data": [{
                		"session_id": "087f742d7d2a34de7eaaf813e5069aaa",
                		"create_date": "2014-02-13 11:43:54",
                		"page": ".MainActivity",
                		"error_log": "XXX XXX XXX XXX…",
                		"stack_trace": "XXX XXX XXX XXX…XXX XXX XXX XXX…"
                	}]
                }, "appkey":"5365f40756240bd7f70f9ea8"}"""

    val msg2= """{"m":{
                	"device_data": {
                	"device_id": "50589a7dc52a2d0",
                		"appver": "1.0",
                	"apppkg": " com.example.sharesdk_test",
                		"platform_id": 1,
                	"sdkver": "1.0.0",
                		"channel_name": "Channel_A",
                		"mac": "d8:50:e6:80:45:98",
                		"model": "Nexus 7",
                		"sysver": "4.4.2",
                		"carrier": "400001",
                		"screensize": "1200x1824",
                		"factory": " asus",
                		"networktype": "Wi-Fi",
                		"is_jailbroken": 0,
                		"longitude": "121.49656",
                		"latitude": "31.21842",
                		"language": "zh",
                		"timezone": 8,
                  	"cpu": "ARMv7 Processor rev 0 (v7l)",
                		"manuid": "KOT49H",
                		"manutime": "1386201442000"
                	},
                	"launch_data": [{
                		"last_end_date": "2014-02-21 12:40:19",
                		"create_date": "2014-02-21 14:40:19",
                		"session_id": "5CEEA3BFF862D1EE437A5A29EABEC372"
                	},
                	{
                		"last_end_date": "2014-02-21 11:50:19",
                		"create_date": "2014-02-21 14:40:19",
                		"session_id": "5CEEA3BFF862D1EE437A5A29EABEC373"
                	},
                {
                      "last_end_date": "2018-02-21 12:40:19",
                      "create_date": "2018-02-21 14:40:19",
                      "session_id": "5CEEA3BFF862D1EE437A5A29EABEC372"
                    },
                    {
                      "last_end_date": "2014-02-21 11:50:19",
                      "create_date": "2014-02-21 14:40:19",
                      "session_id": "5CEEA3BFF862D1EE437A5A29EABEC373"
                    }
                	],
                	"exit_data": [{
                		"create_date": "2014-02-21 14:40:19",
                		"end_date": "2014-02-21 16:40:19",
                		"session_id": "5CEEA3BFF862D1EE437A5A29EABEC372"
                	},
                	{
                		"create_date": "2014-02-21 14:40:19",
                		"end_date": "2014-02-21 15:40:19",
                		"session_id": "5CEEA3BFF862D1EE437A5A29EABEC373"
                	}],
                	"page_data": [{
                		"session_id": "087f742d7d2a34de7eaaf813e5069aaa",
                		"start_date": "2014-02-13 11:41:35",
                		"end_date": "2014-02-13 11:41:38",
                		"page": ".TestActivity",
                		" from_page": ".MainActivity",
                		"duration": 2861
                	}],
                	"event_data": [{
                		"session_id": "087f742d7d2a34de7eaaf813e5069aaa",
                		"create_date": "2014-02-13 11:43:54",
                		"eventkey": "btn_click",
                		"notice_num": 1,
                		"page": ".TestActivity",
                		"label": "stop",
                		"duration": 2861
                	}],
                	"eventkv_data": [{
                		"session_id": "087f742d7d2a34de7eaaf813e5069aaa",
                		"create_date": "2014-02-13 11:43:54",
                		"eventkey": "btn_click",
                		"page": ".MainActivity",
                		"key1": "value1",
                		"key2": "value2",
                		"key3": "value3",
                		"key4": "value4",
                		"key5": "value5",
                		"key6": "value6",
                		"key7": "value7",
                		"key8": "value8",
                		"key9": "value9",
                		"key10": "value10",
                		"notice_num": 1,
                		"label": "stop",
                		"duration": 2861
                	}],
                	"error_data": [{
                		"session_id": "087f742d7d2a34de7eaaf813e5069aaa",
                		"create_date": "2014-02-13 11:43:54",
                		"page": ".MainActivity",
                		"error_log": "XXX XXX XXX XXX…",
                		"stack_trace": "XXX XXX XXX XXX…XXX XXX XXX XXX…"
                	}]
                }, "appkey":"5365f40756240bd7f70f9ea7"}"""

         val msgList = List(msg1,msg2)
          val rand = new Random()
    val index = rand.nextInt(msgList.length)
    msgList(index)



  }





}

object test{
  def main(args: Array[String]) {
    val testmsg = new MsgResource().getMsg()
    println(testmsg)
  }
}
