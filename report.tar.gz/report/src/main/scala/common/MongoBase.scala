package common

import com.mongodb.casbah.MongoClient
import com.mongodb.casbah.commons.MongoDBObject

/**
 * Created by dempe on 14-5-20.
 */
object MongoBase {

  val mongoClient =  MongoClient("localhost", 27001)

  def getClient():MongoClient = {
    mongoClient
  }

  def main(args: Array[String]) {
    // connect to "mongodb02" host, port 42017
    val mongoClient =  MongoClient("localhost", 27001)
    println("db_names:"+ mongoClient.dbNames())
    val test = mongoClient("test")("test")
    test.insert(MongoDBObject("test" -> Map("name" -> "dempe", "age" -> 22)))
    val query = MongoDBObject("test" -> "dempe")
    val update = MongoDBObject("prop" -> Map("name" ->"zheng","age" ->242))
    test.update(query,update,upsert = true)

  }

}
