package test

/**
 * Created by dempe on 14-5-19.
 */
object Test1 {
  def main(args: Array[String]) {
    val list = List(1,4,6,9,33,22,2,4,6,4,5,6)
    val filterList = list.filter(_ % 2 == 0)

    println(filterList)
  }

}
